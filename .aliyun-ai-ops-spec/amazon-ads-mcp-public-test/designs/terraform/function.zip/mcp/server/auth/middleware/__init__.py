"""Middleware for MCP authorization."""
